
QL41 is one of the the most flexible and powerful file viewing util-
ities  available for CP/M.  It combines some of the best features of
the  popular  CP/M, ZCPR3, and MS-DOS utilities LUX,  LT,  VLU,  and
LIST62  with unique features of its own, including hex display  mode
and  a  unique, fast access, file reference by number  system.  This
version  extends the numbered  file access to  the LBR directory and 
adds "batch" viewing/extractions.   LBR extractions, more.  See DOC.
